#import tensorflow.keras.applications.ResNet50
#from keras_applications.resnet import ResNet50
from keras.applications.resnet50 import ResNet50
from keras.preprocessing import image
from keras.applications.resnet50 import preprocess_input, decode_predictions
import numpy as np
from PIL import Image
import ssl
import warnings
warnings.filterwarnings("ignore", message="numpy.dtype size changed")
warnings.filterwarnings("ignore", message="numpy.ufunc size changed")
ssl._create_default_https_context = ssl._create_unverified_context

model = ResNet50(weights='imagenet')

img_path = 'images/test.jpg'

#import pymongo
#from pymongo import MongoClient
 
#cluster = MongoClient("mongodb+srv://nalsadi:passie@cluster0.srlwm.mongodb.net/<dbname>?retryWrites=true&w=majority")
#db = cluster["Data"]
#collection = db["Pred"]


img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)

preds = model.predict(x)
# decode the results into a list of tuples (class, description, probability)
# (one such list for each sample in the batch)
print('Predicted:', decode_predictions(preds, top=3)[0])
f = open("prediction.txt", "w")
f.write(decode_predictions(preds, top=3)[0][0][1])
pred = str(decode_predictions(preds, top=3)[0][0][1])
#post = {"Pred":pred}

#collection.insert_one(post)
f.close()

# Predicted: [(u'n02504013', u'Indian_elephant', 0.82658225), (u'n01871265', u'tusker', 0.1122357), (u'n02504458', u'African_elephant', 0.061040461)]