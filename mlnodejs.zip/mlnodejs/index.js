const express = require('express');
const fileUpload = require('express-fileupload');
const app = express();
var fs = require('fs');
const path = require('path')
const delay = require('delay');
var pred = "empty";
const PORT = process.env.PORT || 8000


app.use(express.static(path.join(__dirname, 'public')))
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'ejs')
  app.get('/', (req, res) => res.render('pages/index'))
  
//app.use(express.static(path.join(__dirname, 'public')))
//app.set('views', path.join(__dirname, 'views'))
//app.set('view engine', 'ejs')
  
//app.get('/', function (req, res) {
  //  res.sendFile('/Users/naseemalsadi/Documents/nodal/index.html');
 // res.render('pages/index')
//});
// default options



app.use(fileUpload());

function function2() {
    // all the stuff you want to happen after that pause
    console.log('Blah blah blah blah extra-blah');
}


app.post('/upload', function(req, res) {
  if (!req.files || Object.keys(req.files).length === 0) {
    
    return res.status(400).send('No files were uploaded.');
    
  }
  res.render('pages/upload')
  // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
  let sampleFile = req.files.sampleFile;
  //console.log(req.files.sampleFile.mv(''));

  // Use the mv() method to place the file somewhere on your server
  sampleFile.mv(__dirname + '/images/test.jpg', function(err) {
    if (err)
      return res.status(500).send(err);
    
    const spawn = require("child_process").spawn;
    const pythonProcess = spawn('python',["main.py"]);
    //res.send('File uploaded! Image is being classified...')
    //setTimeout(function2, 10000);


    //res.write('<html>');
    //res.write('<body>');
    //res.write('<h1>JS Backed Image Classifier</h1>');
    
   
 
    //var status = 'Loading';
    //res.write(`<h2> ${status}</h2>`);
    //res.redirect('/load.html')

    //setTimeout((function() {status = 'Done';res.write(`<h2>Image was classified as: ${pred}</h2>`);
    //res.write('</body>');
    //res.write('</html>');
    //res.end();}), 16000);
    

  });
});

app.get('/complete', function(req, res) {
  setTimeout((function() {fs.readFile('prediction.txt', 'utf8', function(err, data) {
    if (err) throw err;
    pred = data;
    res.render('pages/complete', { user: data});
    console.log(pred);
    //const spawn = require("child_process").spawn;
    //const pythonProcess = spawn('rm',["images/test.jpg"]);
    //spawn('rm',["prediction.txt"]);
    //res.render('pages/complete')
    //return res.redirect('/complete');
});}), 4000);
  
});
app.listen(PORT, () => console.log(`Listening on ${ PORT }`))
