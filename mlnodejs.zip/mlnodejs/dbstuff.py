import pymongo
from pymongo import MongoClient
 
cluster = MongoClient("mongodb+srv://nalsadi:passie@cluster0.srlwm.mongodb.net/<dbname>?retryWrites=true&w=majority")
db = cluster["Data"]
collection = db["Pred"]

post = {"_id": 0, "Pred":"QWERTY"}

collection.insert_one(post)